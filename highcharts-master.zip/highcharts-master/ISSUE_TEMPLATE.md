#### Expected behaviour


#### Actual behaviour


#### Live demo with steps to reproduce
<!-- template: https://jsfiddle.net/highcharts/LLExL/ -->

#### Product version
<!--- Highcharts, Highstock or Highmaps plus version number -->

#### Affected browser(s)

